package com.pixelart.gcm;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;

/**
*@author PixelartDev - http://pixelartdev.com
* 
* Copyright 2014 GPUv3
*/
public class MainActivity extends Activity {
	
	
    public static final String EXTRA_MESSAGE = "message";
    public static final String PROPERTY_REG_ID = "registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

    String SENDER_ID = "871032584364";
	String URL = "http://demo.pixelartdev.com";
    TextView mDisplay;
    GoogleCloudMessaging gcm;
    AtomicInteger msgId = new AtomicInteger();
    SharedPreferences prefs;
    Context context;
    String regid;
	String responseBody;
	String ms;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mDisplay = (TextView) findViewById(R.id.display);
        
        // for each message type we define a method
		String todo = getIntent().getStringExtra("todo"); 
		if(todo != null) {
	        if(todo.equals("newPost")) {
	        	newPost();
	        }else if(todo.equals("updatePost")) {
	        	updatePost();
	        }else if(todo.equals("message")) {
	        	message();
	        }
		}
        
		
        context = getApplicationContext();

        if (checkPlayServices()) {
            gcm = GoogleCloudMessaging.getInstance(this);
            regid = getRegistrationId(context);
            if (regid.isEmpty()) {
                new registerInBackground().execute();
            }
        } else {
            Log.i("PX WP GCM", "No valid Google Play Services APK found.");
        }
    }
	
	/** Do here something with the new post information **/
	private void newPost() {
		String title = getIntent().getStringExtra("post_title");
    	String url = getIntent().getStringExtra("post_url");
    	String id = getIntent().getStringExtra("post_id");
    	String author = getIntent().getStringExtra("post_author");
    	
    	mDisplay.setText("");
    	mDisplay.setText("Title: "+ title+"\nUrl: "+url+"\nId: "+id+"\nAuthor: "+author);
	}
	
	/** Do here something withe update post information **/
	private void updatePost() {
		String title = getIntent().getStringExtra("post_title");
    	String url = getIntent().getStringExtra("post_url");
    	String id = getIntent().getStringExtra("post_id");
    	String author = getIntent().getStringExtra("post_author");
    	
    	mDisplay.setText("");
    	mDisplay.setText("Title: "+ title+"\nUrl: "+url+"\nId: "+id+"\nAuthor: "+author);
	}
	
	/** Do here something with the message **/
	private void message() {
		String ms = getIntent().getStringExtra("msg");
		mDisplay.setText("");
		mDisplay.setText("Message: "+ms);
	}
	
	
/**
 *  GCM Registration Part - REGISTRATION TO YOUR WEBSITE
 */
	private boolean checkPlayServices() {
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, this, PLAY_SERVICES_RESOLUTION_REQUEST).show();
			}else {
				Log.i("PX WP GCM", "This device is not supported.");
				finish();
			}
			return false;
		}
		return true;
	}
	
	private String getRegistrationId(Context context) {
		final SharedPreferences prefs = getGCMPreferences(context);
		String registrationId = prefs.getString(PROPERTY_REG_ID, "");
		if(registrationId.isEmpty()) {
			Log.i("PX WP GCM", "Registration not found.");
			return "";
		}
	
		int registeredVersion = prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
		int currentVersion = getAppVersion(context);
		if(registeredVersion != currentVersion) {
			Log.i("PX WP GCM", "App version changed.");
			return "";
		}
		return registrationId;
	}
	
	private SharedPreferences getGCMPreferences(Context context) {
		return getSharedPreferences(MainActivity.class.getSimpleName(), Context.MODE_PRIVATE);
	}
	
	private static int getAppVersion(Context context) {
		try {
			PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			return packageInfo.versionCode;
		} catch (PackageManager.NameNotFoundException e) {
			throw new RuntimeException("Could not get package name: " + e);
		}
	}
	
	private class registerInBackground extends AsyncTask<Void, Integer, String> {
		@Override
        protected String doInBackground(Void... params) {
            String msg = "";
            try {
                if(gcm == null) {
                    gcm = GoogleCloudMessaging.getInstance(context);
                }
                regid = gcm.register(SENDER_ID);
                msg = "Device registered \n registration ID=" + regid;
                sendRegistrationIdToBackend();
				
                storeRegistrationId(context, regid);
            }catch (IOException ex) {
                msg = "Error :" + ex.getMessage();
            }
            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {
            mDisplay.append(msg + "\n");
        }
	}
	
	private void sendRegistrationIdToBackend() {
		String os = android.os.Build.VERSION.RELEASE;
		String model = getDeviceName();
		os = os.replaceAll(" ", "%20");
		model = model.replaceAll(" ", "%20");
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(URL+"/?regId="+regid+"&os=Android%20"+os+"&model="+model);
		try {
			HttpResponse response = httpclient.execute(httppost);	
			responseBody = EntityUtils.toString(response.getEntity());

		} catch (ClientProtocolException e) {
		} catch (IOException e) {
		}
	}
	
	private void storeRegistrationId(Context context, String regId) {
		final SharedPreferences prefs = getGCMPreferences(context);
		int appVersion = getAppVersion(context);
		Log.i("PX WP GCM", "Saving regId on app version " + appVersion);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(PROPERTY_REG_ID, regId);
		editor.putInt(PROPERTY_APP_VERSION, appVersion);
		editor.commit();
	}
	
	// Get the device model name with manufacturer
	public String getDeviceName() {
	    String manufacturer = Build.MANUFACTURER;
	    String model = Build.MODEL;
	    if (model.startsWith(manufacturer)) {
	        return capitalize(model);
	    } else {
	        return capitalize(manufacturer) + " " + model;
	    }
	}

	private String capitalize(String s) {
	    if (s == null || s.length() == 0) {
	        return "";
	    }
	    char first = s.charAt(0);
	    if (Character.isUpperCase(first)) {
	        return s;
	    } else {
	        return Character.toUpperCase(first) + s.substring(1);
	    }
	} 
}